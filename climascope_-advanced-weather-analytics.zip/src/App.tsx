/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  HelpCircle,
  LayoutDashboard,
  Zap,
  Info,
  RefreshCcw,
  Sparkles,
  ChevronRight,
  Database,
  Download,
  Bot,
  BrainCircuit,
  MessageSquare,
  Thermometer,
  Droplets,
  Wind,
  CloudRain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

import { generateHistoricalData, calculateStats, getCorrelationMatrix, detectAnomalies, fetchKaggleSeattleData, fetchKaggleSzegedData, getSeasonalTrends, SeasonalPattern, exportWeatherDataToCSV } from './services/weatherData';
import { getAIWeatherInsights, getDailyWeatherPrediction, PredictionResult } from './services/geminiService';
import { WeatherData, Stats } from './types';

import StatsGrid from './components/StatsGrid';
import WeatherChart from './components/WeatherChart';
import CorrelationMatrix from './components/CorrelationMatrix';
import SeasonalChart from './components/SeasonalChart';
import ForecastCard from './components/ForecastCard';
import Onboarding from './components/Onboarding';

export default function App() {
  const [data, setData] = useState<WeatherData[]>([]);
  const [selectedVar, setSelectedVar] = useState<'temperature' | 'rainfall' | 'humidity' | 'windSpeed'>('temperature');
  const [aiInsights, setAiInsights] = useState<string>('');
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const [isLoadingPrediction, setIsLoadingPrediction] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'analysis' | 'ai'>('overview');
  const [dataSource, setDataSource] = useState<'local' | 'seattle' | 'szeged'>('local');
  const [isSyncing, setIsSyncing] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Initialization
  useEffect(() => {
    loadData();
    const hasSeenTour = localStorage.getItem('hasSeenWeatherTour');
    if (!hasSeenTour) {
      setShowOnboarding(true);
      localStorage.setItem('hasSeenWeatherTour', 'true');
    }
  }, [dataSource]);

  const loadData = async () => {
    setIsSyncing(true);
    setPrediction(null);
    try {
      let rawData: WeatherData[] = [];
      if (dataSource === 'local') {
        rawData = generateHistoricalData(365);
      } else if (dataSource === 'seattle') {
        rawData = await fetchKaggleSeattleData();
      } else if (dataSource === 'szeged') {
        rawData = await fetchKaggleSzegedData();
      }
      setData(rawData);
    } catch (error) {
      console.error("Error loading source:", error);
    } finally {
      setIsSyncing(false);
    }
  };

  const stats = useMemo(() => {
    if (data.length === 0) return {} as Record<string, Stats>;
    return {
      temperature: calculateStats(data.map(d => d.temperature)),
      humidity: calculateStats(data.map(d => d.humidity)),
      rainfall: calculateStats(data.map(d => d.rainfall)),
      windSpeed: calculateStats(data.map(d => d.windSpeed)),
    };
  }, [data]);

  const correlations = useMemo(() => {
    if (data.length === 0) return [];
    return getCorrelationMatrix(data);
  }, [data]);

  const seasonalTrends = useMemo(() => {
    if (data.length === 0) return [];
    return getSeasonalTrends(data);
  }, [data]);

  const anomalies = useMemo(() => {
    return data.filter(d => d.isAnomaly?.temperature || d.isAnomaly?.rainfall);
  }, [data]);

  const handleGenerateInsights = async () => {
    setIsLoadingInsights(true);
    const insights = await getAIWeatherInsights(stats, correlations, seasonalTrends);
    setAiInsights(insights);
    setIsLoadingInsights(false);
    setActiveTab('ai');
  };

  const handleGeneratePrediction = async () => {
    if (data.length === 0) return;
    setIsLoadingPrediction(true);
    const res = await getDailyWeatherPrediction(data);
    setPrediction(res);
    setIsLoadingPrediction(false);
  };

  const handleExportCSV = () => {
    if (data.length === 0) return;
    const csvContent = exportWeatherDataToCSV(data);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `weather_data_${dataSource}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-natural-bg text-natural-text font-sans selection:bg-natural-sage-light/30">
      <Onboarding isOpen={showOnboarding} onClose={() => setShowOnboarding(false)} />
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-natural-border px-8 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-natural-sage rounded-lg flex items-center justify-center shadow-lg shadow-natural-sage/20">
            <Zap className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 id="app-title" className="text-xl font-bold tracking-tight text-natural-dark">ClimaScope</h1>
            <p className="text-[9px] font-mono text-natural-sage uppercase tracking-[0.2em] font-bold">Weather Intelligence Simulation</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowOnboarding(true)}
            className="p-2 hover:bg-natural-bg rounded-full transition-colors text-natural-sage"
            title="Show Guide"
          >
            <HelpCircle className="w-5 h-5" />
          </button>
          <div className="h-6 w-[1px] bg-natural-border" />
          <button 
            onClick={handleExportCSV}
            disabled={data.length === 0}
            className="p-2 hover:bg-natural-bg rounded-full transition-colors text-natural-sage disabled:opacity-30"
            title="Export Current Data to CSV"
          >
            <Download className="w-5 h-5" />
          </button>
          <div className="h-6 w-[1px] bg-natural-border" />
          <button 
            onClick={loadData}
            disabled={isSyncing}
            className="p-2 hover:bg-natural-bg rounded-full transition-colors text-natural-sage disabled:opacity-30"
            title="Sync Data Source"
          >
            <RefreshCcw className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
          </button>
          <div className="h-6 w-[1px] bg-natural-border" />
          <div className="flex items-center gap-2 px-3 py-1 bg-natural-sage-light text-natural-sage text-[10px] font-bold rounded-full uppercase tracking-wider">
            <div className="w-1.5 h-1.5 rounded-full bg-natural-sage animate-pulse" />
            Active Simulation
          </div>
        </div>
      </header>

      <main className="max-w-[1700px] mx-auto p-6 grid grid-cols-1 lg:grid-cols-[260px_1fr_260px] gap-6">
        
        {/* Left Rail: Controls & Mentor */}
        <aside className="space-y-6">
          <div className="bg-[#E1E4D9] p-5 rounded-2xl border border-[#D1D4C9]" id="data-repo-control">
            <div className="flex items-center gap-2 mb-3">
              <Database className="w-4 h-4 text-natural-sage" />
              <h3 className="text-xs font-bold text-natural-sage uppercase tracking-widest">Data Repository</h3>
            </div>
            <p className="text-[10px] leading-relaxed mb-4 text-natural-text/60">
              Select a repository to import environmental telemetry for this simulation.
            </p>
            <div className="grid grid-cols-1 gap-2">
              <button 
                onClick={() => setDataSource('local')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border ${dataSource === 'local' ? 'bg-natural-sage text-white border-natural-sage shadow-sm' : 'bg-white text-natural-sage border-natural-border hover:bg-natural-bg'}`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${dataSource === 'local' ? 'bg-white' : 'bg-natural-sage'}`} />
                Internal Sim
              </button>
              <button 
                onClick={() => setDataSource('seattle')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border ${dataSource === 'seattle' ? 'bg-natural-sage text-white border-natural-sage shadow-sm' : 'bg-white text-natural-sage border-natural-border hover:bg-natural-bg'}`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${dataSource === 'seattle' ? 'bg-white' : 'bg-natural-sage'}`} />
                Kaggle: Seattle
              </button>
              <button 
                onClick={() => setDataSource('szeged')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border ${dataSource === 'szeged' ? 'bg-natural-sage text-white border-natural-sage shadow-sm' : 'bg-white text-natural-sage border-natural-border hover:bg-natural-bg'}`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${dataSource === 'szeged' ? 'bg-white' : 'bg-natural-sage'}`} />
                Kaggle: Szeged
              </button>
            </div>
          </div>

          <div className="bg-[#E1E4D9] p-5 rounded-2xl border border-[#D1D4C9]">
            <div className="flex items-center gap-2 mb-3">
              <Bot className="w-4 h-4 text-natural-sage" />
              <h3 className="text-xs font-bold text-natural-sage uppercase tracking-widest">Interactive Mentor</h3>
            </div>
            <p className="text-sm leading-relaxed mb-4 text-natural-text/80 italic">
              "We're analyzing historical patterns. Should we prioritize seasonal correlation or anomaly detection for this simulation?"
            </p>
            <div className="space-y-2">
              <button 
                onClick={() => setActiveTab('analysis')}
                className="w-full flex items-center justify-center gap-2 py-2 bg-natural-sage text-white text-xs rounded-lg font-medium hover:bg-natural-sage/90 transition-colors"
                id="cta-analysis"
              >
                <BarChart3 className="w-3.5 h-3.5" />
                Analyze Correlations
              </button>
              <button 
                onClick={() => setActiveTab('overview')}
                className="w-full flex items-center justify-center gap-2 py-2 bg-white text-natural-sage text-xs rounded-lg border border-natural-sage font-medium hover:bg-natural-bg transition-colors"
                id="cta-overview"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                Dashboard Overview
              </button>
            </div>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-natural-border shadow-sm">
            <div className="flex items-center gap-2 mb-4 italic">
              <Sparkles className="w-3.5 h-3.5 text-natural-gold" />
              <h3 className="text-[10px] font-bold text-natural-gold uppercase tracking-widest leading-none">Innovative Hints</h3>
            </div>
            <ul className="space-y-4">
              <li className="flex gap-3">
                <BrainCircuit className="w-4 h-4 text-natural-gold shrink-0 mt-0.5" />
                <p className="text-[11px] text-natural-text/70 leading-normal">Apply <b>Statistical Normalization</b> to detect hidden cyclical wind patterns.</p>
              </li>
              <li className="flex gap-3">
                <Sparkles className="w-4 h-4 text-natural-gold shrink-0 mt-0.5" />
                <p className="text-[11px] text-natural-text/70 leading-normal">Use <b>AI-Inference</b> to suggest futuristic city-planning resilience strategies.</p>
              </li>
            </ul>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-natural-border shadow-sm">
            <h3 className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
              Anomaly Intelligence
            </h3>
            <div className="space-y-3 max-h-[200px] overflow-y-auto pr-1 custom-scrollbar">
              {anomalies.length > 0 ? (
                anomalies.map((a, i) => (
                  <div key={i} className="p-2.5 bg-red-50 rounded-lg border border-red-100">
                    <div className="text-[9px] font-bold text-red-600 mb-1">{a.date}</div>
                    <div className="text-[10px] text-red-800 leading-tight">
                      {a.isAnomaly?.temperature && `Temperature spike: ${a.temperature}°C `}
                      {a.isAnomaly?.rainfall && `Rainfall surge: ${a.rainfall}mm`}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-[10px] text-gray-400 italic">No significant anomalies detected in recent cycle.</p>
              )}
            </div>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-natural-border shadow-sm" id="variable-selector">
            <div className="space-y-2">
              {(['temperature', 'humidity', 'rainfall', 'windSpeed'] as const).map(v => {
                const Icon = {
                  temperature: Thermometer,
                  humidity: Droplets,
                  rainfall: CloudRain,
                  windSpeed: Wind
                }[v];
                
                return (
                  <button
                    key={v}
                    onClick={() => setSelectedVar(v)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${selectedVar === v ? 'bg-natural-sage text-white border-natural-sage shadow-sm' : 'text-natural-text border-transparent hover:bg-natural-bg'}`}
                  >
                    <Icon className={`w-4 h-4 ${selectedVar === v ? 'text-white' : 'text-natural-sage'}`} />
                    <span className="capitalize">{v}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Center Content Area */}
        <section className="space-y-6">
          <AnimatePresence mode="wait">
            {activeTab !== 'ai' ? (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="bg-white p-8 rounded-3xl border border-natural-border shadow-sm flex flex-col">
                  <header className="flex justify-between items-center mb-8">
                    <div>
                      <h2 className="font-serif text-3xl text-natural-dark leading-tight">{activeTab === 'overview' ? 'Seasonal Trends' : 'Variable Correlation'}</h2>
                      <p className="text-xs text-natural-text/50 mt-1 uppercase tracking-widest font-bold">Telemetry Unit: Global_Standard_Obs</p>
                    </div>
                    <div className="flex space-x-2">
                      <div className="h-2 w-12 bg-natural-sage rounded-full" />
                      <div className="h-2 w-8 bg-natural-sage-light rounded-full" />
                    </div>
                  </header>

                  <div className="h-[400px]">
                    {activeTab === 'overview' ? (
                      <WeatherChart data={data} type={selectedVar} chartStyle="area" />
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 h-full">
                        <div className="space-y-6">
                           <h4 className="text-[10px] font-bold text-natural-sage uppercase mb-3 px-2 border-l-2 border-natural-sage">Variable Correlation</h4>
                           <CorrelationMatrix correlations={correlations} />
                        </div>
                        <div className="space-y-6">
                            <h4 className="text-[10px] font-bold text-natural-sage uppercase mb-3 px-2 border-l-2 border-natural-sage">Seasonal Pattern Detection</h4>
                            <SeasonalChart data={seasonalTrends} />
                            <div className="p-4 bg-natural-bg rounded-xl border border-natural-border">
                               <h4 className="text-[10px] font-bold text-natural-sage uppercase mb-1">Trend Discovery</h4>
                               <p className="text-[11px] text-natural-text/70 italic">"Autonomous detection identifies cyclical shifts in temperature and precipitation levels across the monthly spectrum."</p>
                            </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Forecast Section */}
                <div className="bg-[#E1E4D9] p-6 rounded-3xl border border-[#D1D4C9]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                    <div>
                      <h3 className="text-sm font-bold text-natural-sage uppercase tracking-widest mb-1">Predictive Analytics</h3>
                      <p className="text-[10px] text-natural-text/50 font-bold uppercase tracking-widest">Day-Wise Weather Projection</p>
                    </div>
                    
                    <button 
                      onClick={handleGeneratePrediction}
                      disabled={isLoadingPrediction || data.length === 0}
                      className="flex items-center gap-2 px-5 py-2 bg-natural-sage text-white text-[10px] font-bold rounded-xl uppercase tracking-widest hover:bg-natural-sage/90 transition-all shadow-md shadow-natural-sage/20 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Sparkles className={`w-3 h-3 ${isLoadingPrediction ? 'animate-spin' : ''}`} />
                      {isLoadingPrediction ? 'Calculating Patterns...' : 'Generate 3-Day Forecast'}
                    </button>
                  </div>

                  {prediction ? (
                    <ForecastCard prediction={prediction} />
                  ) : (
                    <div className="h-[200px] flex flex-col items-center justify-center border-2 border-dashed border-natural-border rounded-2xl bg-white/50">
                      <div className="w-10 h-10 bg-natural-bg rounded-full flex items-center justify-center mb-3">
                        <TrendingUp className="w-5 h-5 text-natural-text/30" />
                      </div>
                      <p className="text-[10px] font-bold text-natural-text/30 uppercase tracking-widest">Initialize forecast engine</p>
                    </div>
                  )}
                </div>

                <StatsGrid stats={stats} />

                <div className="h-24 bg-natural-sage-light rounded-2xl flex items-center px-8 border border-[#B8CDC7]">
                  <div className="flex-1">
                    <h4 className="text-[10px] font-bold text-natural-sage uppercase tracking-wider">Optimistic Forecast</h4>
                    <p className="text-sm text-natural-sage/80 font-medium">Initial analysis suggests high confidence indices for predictive climatic modeling this cycle.</p>
                  </div>
                  <button 
                    onClick={handleGenerateInsights}
                    id="ai-insights-tab"
                    className="px-6 py-2.5 bg-white text-natural-sage rounded-full text-xs font-bold shadow-sm hover:bg-natural-bg transition-all flex items-center gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Run AI Suite
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="ai"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="bg-white rounded-3xl border border-natural-border shadow-xl min-h-[600px] flex flex-col"
              >
                <div className="p-8 border-b border-natural-border flex items-center justify-between bg-natural-bg/30">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-natural-dark rounded-full flex items-center justify-center border-2 border-natural-sage shadow-inner overflow-hidden">
                      <div className="text-white font-serif italic text-lg select-none">AI</div>
                    </div>
                    <div>
                      <h2 className="text-xl font-serif text-natural-dark">Climatic Intelligence Report</h2>
                      <p className="text-[9px] text-natural-sage font-bold uppercase tracking-[0.2em]">Session Simulation_88A</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setActiveTab('overview')}
                    className="text-xs font-bold text-natural-sage hover:underline"
                  >
                    Return to Dashboard
                  </button>
                </div>
                
                <div className="p-10 max-w-3xl mx-auto flex-1">
                  {aiInsights ? (
                    <div className="prose prose-sm prose-emerald max-w-none prose-headings:font-serif prose-headings:text-natural-dark prose-p:text-natural-text/80">
                      <ReactMarkdown>{aiInsights}</ReactMarkdown>
                    </div>
                  ) : isLoadingInsights ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4 text-natural-sage">
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}>
                        <Sparkles className="w-12 h-12 opacity-40" />
                      </motion.div>
                      <p className="text-xs font-bold tracking-widest uppercase animate-pulse">Consulting Expert Intelligence</p>
                    </div>
                  ) : (
                    <div className="py-20 text-center">
                      <Sparkles className="w-12 h-12 text-natural-sage-light mx-auto mb-4" />
                      <p className="text-natural-text/50 mb-6 font-medium italic">"Analysis ready for AI synthesis..."</p>
                      <button onClick={handleGenerateInsights} className="px-8 py-3 bg-natural-sage text-white rounded-full font-bold shadow-lg hover:shadow-xl transition-all">
                        Generate Insights
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Right Rail: Evaluation Readiness */}
        <aside className="bg-natural-dark rounded-3xl p-6 text-white flex flex-col gap-6 shadow-2xl">
          <h3 className="text-[10px] font-bold text-natural-sage-light uppercase tracking-widest py-1 border-b border-white/10">Project Evaluation</h3>
          
          <div className="space-y-6 overflow-y-auto pr-1 flex-1">
            <div className="group">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-emerald-400 text-[10px]">✅</span>
                <span className="text-[9px] uppercase font-bold text-white/50 tracking-wider">Objectives</span>
              </div>
              <p className="text-[11px] leading-relaxed text-white/80 group-hover:text-white transition-colors">Study historical weather variables to uncover seasonal multi-variate dependencies.</p>
            </div>

            <div className="group">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-blue-400 text-[10px]">🔧</span>
                <span className="text-[9px] uppercase font-bold text-white/50 tracking-wider">Methods</span>
              </div>
              <p className="text-[11px] leading-relaxed text-white/80">Pearson correlation, moving average smoothing, and LLM-grounded pattern detection.</p>
            </div>

            <div className="group">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-amber-400 text-[10px]">💡</span>
                <span className="text-[9px] uppercase font-bold text-white/50 tracking-wider">Benefits</span>
              </div>
              <p className="text-[11px] leading-relaxed text-white/80">Hyper-local agricultural optimization and proactive disaster risk assessment protocols.</p>
            </div>

            <div className="group">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-red-400 text-[10px]">⚠️</span>
                <span className="text-[9px] uppercase font-bold text-white/50 tracking-wider">Challenges</span>
              </div>
              <p className="text-[11px] leading-relaxed text-white/80">High volatility in simulated micro-climate nodes and potential data stochasticity.</p>
            </div>

            <div className="pt-6 border-t border-white/10 group">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-purple-400 text-[10px]">🚀</span>
                <span className="text-[9px] uppercase font-bold text-natural-sage-light tracking-wider">Future Scope</span>
              </div>
              <p className="text-[11px] leading-relaxed text-white/60 italic">Integration with real-time IoT constellations and Neural-Net edge processing for global mesh networks.</p>
            </div>
          </div>

          <div className="pt-4 border-t border-white/5">
            <div className="bg-white/5 p-3 rounded-xl border border-white/10">
               <div className="text-[8px] text-white/30 uppercase font-black mb-1">System Health</div>
               <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: '88%' }} className="h-full bg-natural-sage-light" />
               </div>
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="h-12 bg-white border-t border-natural-border px-8 flex items-center justify-between text-[9px] text-natural-text/40 uppercase tracking-[0.2em] font-bold">
        <span>Simulation State: Stable</span>
        <span>Environment: Virtual_WDA_Core</span>
        <span className="hidden md:inline">ClimaScope. &copy; 2024 Pattern Intelligence</span>
      </footer>
    </div>
  );
}
