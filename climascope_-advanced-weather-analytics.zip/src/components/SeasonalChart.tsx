import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { SeasonalPattern } from '../services/weatherData';

interface SeasonalChartProps {
  data: SeasonalPattern[];
}

export default function SeasonalChart({ data }: SeasonalChartProps) {
  return (
    <div className="w-full h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E4D9" strokeOpacity={0.5} />
          <XAxis 
            dataKey="month" 
            tick={{ fontSize: 9, fontWeight: 700, fill: '#A1A9A4' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis hide />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #E1E4D9', fontSize: '10px', fontWeight: 'bold' }}
            cursor={{ fill: '#F4F5F0' }}
          />
          <Legend 
            verticalAlign="top" 
            align="right" 
            iconType="circle"
            wrapperStyle={{ fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', paddingBottom: '20px' }}
          />
          <Bar name="Avg Temp (°C)" dataKey="avgTemp" fill="#4A6D55" radius={[4, 4, 0, 0]} />
          <Bar name="Avg Rain (mm)" dataKey="avgRain" fill="#8C7851" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
