import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, LineChart, Line, ComposedChart
} from 'recharts';
import { WeatherData } from '../types';

interface WeatherChartProps {
  data: WeatherData[];
  type: 'temperature' | 'rainfall' | 'humidity' | 'windSpeed';
  chartStyle: 'area' | 'bar' | 'line';
}

export default function WeatherChart({ data, type, chartStyle }: WeatherChartProps) {
  const configs = {
    temperature: { color: '#4A6D55', label: 'Temperature (°C)' }, // Sage
    humidity: { color: '#D1E1DC', label: 'Humidity (%)' },       // Light Sage
    rainfall: { color: '#8C7851', label: 'Rainfall (mm)' },      // Gold
    windSpeed: { color: '#2D332F', label: 'Wind Speed (km/h)' }, // Slate
  };

  const current = configs[type];

  // Aggregate by month for better visualization if data is large
  const displayData = data.filter((_, i) => i % 7 === 0); // Show weekly data points for 1 year

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload;
      const isAnomaly = dataPoint.isAnomaly?.[type];
      return (
        <div className="bg-white border border-natural-border p-3 rounded-xl shadow-xl text-[10px] font-bold uppercase tracking-wider">
          <p className="border-b border-natural-bg mb-2 pb-1 text-natural-text/50">{label}</p>
          <p style={{ color: current.color }}>
            {current.label}: {payload[0].value.toFixed(1)}
          </p>
          {isAnomaly && (
            <p className="text-red-500 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
              ANOMALY DETECTED
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  const renderAnomalyDot = (props: any) => {
    const { cx, cy, payload } = props;
    const isAnomaly = payload.isAnomaly?.[type];
    
    if (isAnomaly) {
      return (
        <circle 
          cx={cx} 
          cy={cy} 
          r={6} 
          fill="#ef4444" 
          stroke="#fff" 
          strokeWidth={2}
          className="animate-pulse"
        />
      );
    }
    return null;
  };

  return (
    <div className="w-full h-full min-h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        {chartStyle === 'area' ? (
          <ComposedChart data={displayData}>
            <defs>
              <linearGradient id={`grad-${type}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={current.color} stopOpacity={0.2}/>
                <stop offset="95%" stopColor={current.color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E4D9" strokeOpacity={0.5} />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 9, fontWeight: 700, fill: '#A1A9A4' }} 
              tickFormatter={(val) => new Date(val).toLocaleDateString('default', { month: 'short' }).toUpperCase()}
              axisLine={false}
              tickLine={false}
              dy={10}
            />
            <YAxis hide domain={['auto', 'auto']} />
            <Tooltip content={<CustomTooltip />} />
            <Area 
              type="monotone" 
              dataKey={type} 
              stroke={current.color} 
              fillOpacity={1} 
              fill={`url(#grad-${type})`} 
              strokeWidth={3}
              dot={renderAnomalyDot}
            />
          </ComposedChart>
        ) : chartStyle === 'bar' ? (
          <BarChart data={displayData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E4D9" strokeOpacity={0.5} />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 9, fontWeight: 700, fill: '#A1A9A4' }} 
              tickFormatter={(val) => new Date(val).toLocaleDateString('default', { month: 'short' }).toUpperCase()}
              axisLine={false}
              tickLine={false}
              dy={10}
            />
            <YAxis hide domain={['auto', 'auto']} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey={type} radius={[4, 4, 0, 0]} barSize={20}>
              {displayData.map((entry, index) => (
                <rect 
                  key={`cell-${index}`} 
                  fill={entry.isAnomaly?.[type] ? '#ef4444' : current.color} 
                />
              ))}
            </Bar>
          </BarChart>
        ) : (
          <LineChart data={displayData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E4D9" strokeOpacity={0.5} />
            <XAxis 
              dataKey="date" 
              tick={{ fontSize: 9, fontWeight: 700, fill: '#A1A9A4' }} 
              tickFormatter={(val) => new Date(val).toLocaleDateString('default', { month: 'short' }).toUpperCase()}
              axisLine={false}
              tickLine={false}
              dy={10}
            />
            <YAxis hide domain={['auto', 'auto']} />
            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey={type} 
              stroke={current.color} 
              strokeWidth={3} 
              dot={renderAnomalyDot}
              activeDot={{ r: 5, fill: current.color, stroke: '#fff', strokeWidth: 2 }}
            />
          </LineChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
