import { Stats } from '../types';
import { Thermometer, Droplets, CloudRain, Wind } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface StatsGridProps {
  stats: Record<string, Stats>;
}

export default function StatsGrid({ stats }: StatsGridProps) {
  const cards = [
    { label: 'Temperature', key: 'temperature', icon: Thermometer, unit: '°C', color: 'text-natural-gold' },
    { label: 'Humidity', key: 'humidity', icon: Droplets, unit: '%', color: 'text-natural-sage' },
    { label: 'Rainfall', key: 'rainfall', icon: CloudRain, unit: 'mm', color: 'text-natural-sage-light' },
    { label: 'Wind Speed', key: 'windSpeed', icon: Wind, unit: 'km/h', color: 'text-natural-text/40' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, idx) => {
        const data = stats[card.key];
        if (!data) return null;
        
        return (
          <motion.div
            key={card.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="p-5 bg-white border border-natural-border rounded-2xl shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-bold tracking-widest text-natural-text/40 uppercase">{card.label}</span>
              <div className={cn("p-1.5 rounded-lg bg-natural-bg group-hover:bg-opacity-80 transition-colors", card.color)}>
                <card.icon className="w-4 h-4" />
              </div>
            </div>
            
            <div className="flex flex-col gap-1">
              <div className="text-2xl font-serif font-bold text-natural-dark flex items-baseline gap-1">
                {data.avg.toFixed(1)}
                <span className="text-xs font-sans font-medium text-natural-text/30 tracking-tight">{card.unit}</span>
              </div>
              <div className="flex justify-between text-[9px] text-natural-text/40 font-bold tracking-widest mt-4 pt-3 border-t border-natural-bg uppercase">
                <span>MIN: {data.min.toFixed(0)}</span>
                <span>MAX: {data.max.toFixed(0)}</span>
                <span>σ: {data.stdDev.toFixed(1)}</span>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
