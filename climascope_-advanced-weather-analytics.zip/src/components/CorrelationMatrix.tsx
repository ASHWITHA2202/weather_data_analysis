import { CorrelationResult } from '../types';
import { motion } from 'motion/react';

interface CorrelationMatrixProps {
  correlations: CorrelationResult[];
}

export default function CorrelationMatrix({ correlations }: CorrelationMatrixProps) {
  const vars = ['temperature', 'humidity', 'rainfall', 'windSpeed'];
  
  const getCoefficient = (v1: string, v2: string) => {
    return correlations.find(c => 
      (c.var1 === v1 && c.var2 === v2) || (c.var1 === v2 && c.var2 === v1)
    )?.coefficient || 0;
  };

  const getHeatColor = (val: number) => {
    const abs = Math.abs(val);
    if (val > 0) return `rgba(74, 109, 85, ${abs * 0.9})`; // Sage for positive
    return `rgba(140, 120, 81, ${abs * 0.9})`; // Gold for negative
  };

  return (
    <div className="overflow-x-auto p-2">
      <div className="min-w-[400px]">
        <div className="grid grid-cols-[100px_repeat(4,1fr)] gap-3 mb-3">
          <div />
          {vars.map(v => (
            <div key={v} className="text-[9px] font-bold text-natural-text/40 uppercase text-center truncate tracking-tighter">
              {v}
            </div>
          ))}
        </div>
        
        {vars.map(v1 => (
          <div key={v1} className="grid grid-cols-[100px_repeat(4,1fr)] gap-3 mb-3">
            <div className="text-[9px] font-bold text-natural-text/40 uppercase flex items-center pr-2 truncate">
              {v1}
            </div>
            {vars.map(v2 => {
              const coeff = getCoefficient(v1, v2);
              return (
                <motion.div
                  key={`${v1}-${v2}`}
                  whileHover={{ scale: 1.05 }}
                  style={{ backgroundColor: getHeatColor(coeff) }}
                  className="aspect-square flex flex-col items-center justify-center rounded-xl border border-white/20 select-none cursor-help group relative shadow-sm"
                >
                  <span className="text-xs font-mono font-bold text-white shadow-sm">
                    {coeff.toFixed(2)}
                  </span>
                  
                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-2 hidden group-hover:block z-50 bg-natural-dark text-white text-[10px] p-2 rounded-lg whitespace-nowrap shadow-xl border border-white/10 uppercase tracking-widest font-bold">
                    {v1} x {v2}
                  </div>
                </motion.div>
              );
            })}
          </div>
        ))}
      </div>
      
      <div className="mt-8 flex items-center gap-6 text-[10px] font-bold uppercase tracking-widest text-natural-text/30">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#4A6D55]" />
          <span>Positive Correlation</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#8C7851]" />
          <span>Negative Correlation</span>
        </div>
      </div>
    </div>
  );
}
