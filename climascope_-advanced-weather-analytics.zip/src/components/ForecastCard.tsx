import { motion } from 'motion/react';
import { CloudRain, Sun, Thermometer, Zap } from 'lucide-react';
import { PredictionResult } from '../services/geminiService';

interface ForecastCardProps {
  prediction: PredictionResult;
}

export default function ForecastCard({ prediction }: ForecastCardProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {prediction.forecast.map((f, idx) => (
        <motion.div
          key={f.day}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: idx * 0.1 }}
          className="p-5 bg-white rounded-2xl border border-natural-border shadow-sm hover:shadow-md transition-all group"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="text-[10px] font-bold text-natural-sage uppercase tracking-widest px-2 py-1 bg-natural-sage-light rounded-md">
              Day +{f.day}
            </div>
            {f.rain > 5 ? (
              <CloudRain className="w-5 h-5 text-natural-gold animate-bounce" />
            ) : (
              <Sun className="w-5 h-5 text-[#8C7851] group-hover:rotate-12 transition-transform" />
            )}
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-natural-bg rounded-lg">
                <Thermometer className="w-4 h-4 text-natural-sage" />
              </div>
              <div>
                <div className="text-xl font-bold text-natural-dark">{f.temp.toFixed(1)}°C</div>
                <div className="text-[9px] font-bold text-natural-text/40 uppercase tracking-tighter">Projected Temp</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 bg-natural-bg rounded-lg">
                <CloudRain className="w-4 h-4 text-natural-sage" />
              </div>
              <div>
                <div className="text-xl font-bold text-natural-dark">{f.rain.toFixed(1)}mm</div>
                <div className="text-[9px] font-bold text-natural-text/40 uppercase tracking-tighter">Expected Precipitation</div>
              </div>
            </div>

            <div className="pt-3 border-t border-natural-bg">
              <p className="text-[11px] leading-relaxed text-natural-text/70 italic line-clamp-2">
                "{f.outlook}"
              </p>
            </div>
          </div>
        </motion.div>
      ))}
      
      <div className="md:col-span-3 flex justify-between items-center px-4 py-2 bg-natural-dark text-white rounded-xl">
        <div className="flex items-center gap-2">
          <Zap className="w-3 h-3 text-natural-gold" />
          <span className="text-[9px] font-bold uppercase tracking-[0.2em]">AI Confidence Matrix</span>
        </div>
        <div className="text-[10px] font-mono font-bold">{prediction.confidence}%</div>
      </div>
    </div>
  );
}
