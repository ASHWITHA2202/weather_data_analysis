import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronRight, ChevronLeft, Sparkles, Target, Zap, Waves } from 'lucide-react';

interface Step {
  title: string;
  description: string;
  targetId: string;
  icon: any;
}

const steps: Step[] = [
  {
    title: "Data Repositories",
    description: "Switch between Internal simulations and real-world datasets from Seattle or Szeged (Kaggle). This changes the baseline telemetry for all models.",
    targetId: "data-repo-control",
    icon: Target
  },
  {
    title: "Correlation Analysis",
    description: "Discover hidden relationships between environmental variables. A coefficient closer to 1.0 indicates a strong dependency.",
    targetId: "cta-analysis",
    icon: Waves
  },
  {
    title: "Anomaly Detection",
    description: "Our algorithms highlight data points that deviate from the statistical norm, crucial for identifying extreme weather events.",
    targetId: "variable-selector",
    icon: Zap
  },
  {
    title: "AI-Driven Insights",
    description: "Leverage Gemini to synthesize complex patterns into actionable strategies for city planning and industrial automation.",
    targetId: "ai-insights-tab",
    icon: Sparkles
  }
];

interface OnboardingProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Onboarding({ isOpen, onClose }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const step = steps[currentStep];
  const Icon = step.icon;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-natural-dark/40 backdrop-blur-sm flex items-center justify-center p-4"
      >
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-white rounded-[32px] border border-natural-border shadow-2xl max-w-md w-full overflow-hidden"
        >
          <div className="p-8">
            <div className="flex justify-between items-center mb-8">
              <div className="w-12 h-12 bg-natural-sage-light rounded-2xl flex items-center justify-center">
                <Icon className="w-6 h-6 text-natural-sage" />
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-natural-bg rounded-full transition-colors text-natural-text/30"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 mb-12">
              <div className="text-[10px] font-bold text-natural-sage uppercase tracking-[0.2em]">
                Module {currentStep + 1} / {steps.length}
              </div>
              <h2 className="text-2xl font-bold text-natural-dark tracking-tight">
                {step.title}
              </h2>
              <p className="text-sm leading-relaxed text-natural-text/70 italic">
                "{step.description}"
              </p>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex gap-1.5">
                {steps.map((_, idx) => (
                  <div 
                    key={idx} 
                    className={`h-1 rounded-full transition-all ${idx === currentStep ? 'w-6 bg-natural-sage' : 'w-2 bg-natural-sage-light'}`}
                  />
                ))}
              </div>
              
              <div className="flex gap-3">
                <button
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                  className="p-3 border border-natural-border rounded-xl disabled:opacity-30 hover:bg-natural-bg transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                
                {currentStep < steps.length - 1 ? (
                  <button
                    onClick={() => setCurrentStep(currentStep + 1)}
                    className="flex items-center gap-2 px-6 py-3 bg-natural-sage text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:shadow-lg transition-all"
                  >
                    Next Pattern
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={onClose}
                    className="flex items-center gap-2 px-6 py-3 bg-natural-dark text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:shadow-lg transition-all"
                  >
                    Begin Simulation
                    <Sparkles className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
          
          <div className="px-8 py-4 bg-natural-bg border-t border-natural-border flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-natural-gold animate-pulse" />
             <span className="text-[10px] font-bold text-natural-text/40 uppercase tracking-widest">Global Telemetry Enabled</span>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
