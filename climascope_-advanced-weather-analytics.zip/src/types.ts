export interface WeatherData {
  date: string;
  temperature: number; // Celsius
  humidity: number; // %
  rainfall: number; // mm
  windSpeed: number; // km/h
  isAnomaly?: {
    temperature?: boolean;
    rainfall?: boolean;
  };
}

export interface Stats {
  avg: number;
  min: number;
  max: number;
  stdDev: number;
}

export interface CorrelationResult {
  var1: string;
  var2: string;
  coefficient: number;
}
