import { GoogleGenAI } from "@google/genai";
import { CorrelationResult, Stats, WeatherData } from "../types";
import { SeasonalPattern } from "./weatherData";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const getAIWeatherInsights = async (
  topStats: Record<string, Stats>,
  correlations: CorrelationResult[],
  seasonalPatterns: SeasonalPattern[]
) => {
  if (!process.env.GEMINI_API_KEY) {
    return "AI Insights are unavailable without a Gemini API key. Please check your configuration.";
  }

  const prompt = `
    As a Weather Data Scientist expert with 25+ years of experience, analyze the following climatic metrics:
    
    1. Statistical Summary (Avg, Min, Max, StdDev):
    ${JSON.stringify(topStats, null, 2)}
    
    2. Key Correlations:
    ${correlations.map(c => `[${c.var1}] vs [${c.var2}]: ${c.coefficient.toFixed(2)}`).join('\n')}

    3. Seasonal Trends (Monthly Averages):
    ${JSON.stringify(seasonalPatterns, null, 2)}
    
    Tasks:
    - Identify 3 non-obvious climate or seasonal patterns based on these numbers.
    - Analyze the stability of the environmental cycle across the months.
    - Suggest 2 innovative automation ideas for this specific dataset.
    - Provide a case study scenario for how a city planner might use this data toward resilience.
    
    Tone: Professional, visionary, mentor-like. Use clean markdown formatting.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    
    return response.text || "No insights could be generated at this time.";
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return "Error generating AI insights. Please try again later.";
  }
};

export interface PredictionResult {
  forecast: {
    day: number;
    temp: number;
    rain: number;
    outlook: string;
  }[];
  confidence: number;
}

export const getDailyWeatherPrediction = async (
  recentData: WeatherData[]
): Promise<PredictionResult | null> => {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }

  const prompt = `
    As a Predictive Meteorological Expert, analyze the following recent weather telemetry (last 7 days):
    ${JSON.stringify(recentData.slice(-7), null, 2)}
    
    Tasks:
    1. Provide a 3-day projected forecast (Day +1, +2, +3).
    2. For each day, predict: Avg Temperature, Expected Rainfall, and a brief "Atmospheric Outlook".
    3. Return the response in a structured JSON format:
    {
      "forecast": [
        { "day": 1, "temp": number, "rain": number, "outlook": "string" },
        ...
      ],
      "confidence": number (0-100)
    }
    
    Only return the JSON object. No extra text.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    
    const text = response.text || "";
    const cleanedText = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleanedText);
  } catch (error) {
    console.error("Gemini Prediction Error:", error);
    return null;
  }
};
