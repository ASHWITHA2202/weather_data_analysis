import Papa from 'papaparse';
import { WeatherData, Stats, CorrelationResult } from '../types';

export const generateHistoricalData = (days: number = 365): WeatherData[] => {
  const data: WeatherData[] = [];
  const start = new Date(2023, 0, 1);

  for (let i = 0; i < days; i++) {
    const date = new Date(start);
    date.setDate(start.getDate() + i);
    
    // Seasonal variation (Simple sine wave approximation)
    const dayOfYear = i;
    const tempBase = 20 + 10 * Math.sin((dayOfYear - 100) * 2 * Math.PI / 365);
    const rainSeasonFactor = Math.sin((dayOfYear - 180) * 2 * Math.PI / 365);
    
    data.push({
      date: date.toISOString().split('T')[0],
      temperature: Number((tempBase + (Math.random() * 6 - 3)).toFixed(1)),
      humidity: Math.min(100, Math.max(0, Number((60 + 20 * rainSeasonFactor + (Math.random() * 20 - 10)).toFixed(1)))),
      rainfall: Math.max(0, Number((Math.random() > 0.7 ? (Math.random() * 15 * (rainSeasonFactor + 1)) : 0).toFixed(1))),
      windSpeed: Number((10 + Math.random() * 15).toFixed(1)),
    });
  }
  return detectAnomalies(data);
};

export const fetchKaggleSeattleData = async (): Promise<WeatherData[]> => {
  const url = 'https://raw.githubusercontent.com/vega/vega/main/docs/data/seattle-weather.csv';
  const response = await fetch(url);
  const csvText = await response.text();
  
  return new Promise((resolve) => {
    Papa.parse(csvText, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        const mapped = results.data.map((row: any) => ({
          date: row.date,
          temperature: row.temp_max, // Mapping max temp to temperature
          humidity: 65 + (Math.random() * 20 - 10), // Simulated as original source lacks it
          rainfall: row.precipitation,
          windSpeed: row.wind,
        })) as WeatherData[];
        resolve(detectAnomalies(mapped.filter(d => d.date)));
      }
    });
  });
};

export const fetchKaggleSzegedData = async (): Promise<WeatherData[]> => {
  // Using a mirrored sample of the massive Szeged dataset
  const url = 'https://raw.githubusercontent.com/m-pashmi/szeged-weather/master/weatherHistory.csv';
  const response = await fetch(url);
  const csvText = await response.text();
  
  return new Promise((resolve) => {
    Papa.parse(csvText, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        // Limit to 500 records for performance
        const mapped = results.data.slice(0, 500).map((row: any) => ({
          date: new Date(row['Formatted Date']).toISOString().split('T')[0],
          temperature: row['Temperature (C)'],
          humidity: row['Humidity'] * 100,
          rainfall: row['Precip Type'] === 'rain' ? Math.random() * 5 : 0, // Inferred
          windSpeed: row['Wind Speed (km/h)'],
        })) as WeatherData[];
        resolve(detectAnomalies(mapped.filter(d => d.date)));
      }
    });
  });
};

export const calculateStats = (data: number[]): Stats => {
  const avg = data.reduce((a, b) => a + b, 0) / data.length;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const stdDev = Math.sqrt(data.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / data.length);
  
  return { avg, min, max, stdDev };
};

export const calculateCorrelation = (x: number[], y: number[]): number => {
  const n = x.length;
  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = y.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((a, b, i) => a + b * y[i], 0);
  const sumX2 = x.reduce((a, b) => a + b * b, 0);
  const sumY2 = y.reduce((a, b) => a + b * b, 0);

  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
  
  return denominator === 0 ? 0 : numerator / denominator;
};

export const getCorrelationMatrix = (data: WeatherData[]): CorrelationResult[] => {
  const keys: (keyof Omit<WeatherData, 'date' | 'isAnomaly'>)[] = ['temperature', 'humidity', 'rainfall', 'windSpeed'];
  const correlations: CorrelationResult[] = [];

  for (let i = 0; i < keys.length; i++) {
    for (let j = i; j < keys.length; j++) {
      const x = data.map(d => d[keys[i]] as number);
      const y = data.map(d => d[keys[j]] as number);
      correlations.push({
        var1: keys[i],
        var2: keys[j],
        coefficient: calculateCorrelation(x, y)
      });
    }
  }
  return correlations;
};

export const exportWeatherDataToCSV = (data: WeatherData[]): string => {
  return Papa.unparse(data.map(d => ({
    Date: d.date,
    Temperature_C: d.temperature,
    Humidity_Percent: d.humidity,
    Rainfall_mm: d.rainfall,
    WindSpeed_kmh: d.windSpeed,
    Anomaly_Temp: d.isAnomaly?.temperature ? 'YES' : 'NO',
    Anomaly_Rain: d.isAnomaly?.rainfall ? 'YES' : 'NO'
  })));
};

export const detectAnomalies = (data: WeatherData[]): WeatherData[] => {
  const tempValues = data.map(d => d.temperature);
  const rainValues = data.map(d => d.rainfall);
  
  const tempStats = calculateStats(tempValues);
  const rainStats = calculateStats(rainValues);

  const threshold = 2.5; // Z-score threshold for anomalies

  return data.map(d => {
    const tempZ = Math.abs((d.temperature - tempStats.avg) / (tempStats.stdDev || 1));
    const rainZ = Math.abs((d.rainfall - rainStats.avg) / (rainStats.stdDev || 1));

    return {
      ...d,
      isAnomaly: {
        temperature: tempZ > threshold,
        rainfall: rainZ > threshold && d.rainfall > 5 // Only flag rainfall as anomaly if it's significant
      }
    };
  });
};

export interface SeasonalPattern {
  month: string;
  avgTemp: number;
  avgRain: number;
  avgHumidity: number;
}

export const getSeasonalTrends = (data: WeatherData[]): SeasonalPattern[] => {
  const monthlyData: Record<number, WeatherData[]> = {};
  
  data.forEach(d => {
    const month = new Date(d.date).getMonth();
    if (!monthlyData[month]) monthlyData[month] = [];
    monthlyData[month].push(d);
  });

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  return Object.keys(monthlyData).map(mKey => {
    const mIdx = parseInt(mKey);
    const mData = monthlyData[mIdx];
    return {
      month: months[mIdx],
      avgTemp: mData.reduce((acc, curr) => acc + curr.temperature, 0) / mData.length,
      avgRain: mData.reduce((acc, curr) => acc + curr.rainfall, 0) / mData.length,
      avgHumidity: mData.reduce((acc, curr) => acc + curr.humidity, 0) / mData.length,
    };
  }).sort((a, b) => months.indexOf(a.month) - months.indexOf(b.month));
};
